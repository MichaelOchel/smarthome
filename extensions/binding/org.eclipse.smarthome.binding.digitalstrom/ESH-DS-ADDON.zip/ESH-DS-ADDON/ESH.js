var now = new Date();
var evt;
var evtName = "ESH";

if (raisedEvent.source.isDevice) {
   evt = new Event(evtName,
          {
		  eventName: raisedEvent.name,
             dsid: raisedEvent.source.dsid,
             zoneID: raisedEvent.source.zoneID,
             sceneID: raisedEvent.parameter.sceneID,
             timestamp: now.getTime(),
             isDevice: raisedEvent.source.isDevice,
          }  );

}
else
{
   evt = new Event(evtName,
          {
		  eventName: raisedEvent.name,
             zoneID: raisedEvent.source.zoneID,
             groupID: raisedEvent.source.groupID,
             sceneID: raisedEvent.parameter.sceneID,
             timestamp: now.getTime(),
             isDevice: raisedEvent.source.isDevice,
          }  );
}
evt.raise();
